﻿using NServiceBus;

namespace PayrollGenerator.SagaHandler
{
    using System;
    using NServiceBus.Saga;
    using System.Data.SqlClient;
    using System.IO;
    using PayrollGenerator.Messages;

    public class ProcessOrderCommandHandler : Saga<PayProcessData>, IAmStartedByMessages<PayProcessStarter>, IHandleMessages<PayProcessEnder>
    {
        public IBus Bus { get; set; }

        public override void ConfigureHowToFindSaga()
        {
            this.ConfigureMapping<PayProcessEnder>(x => x.ProcessId).ToSaga(m => m.ProcessId);
        }

        public void Handle(PayProcessStarter message)
        {
            int count = 20;
            this.Data.ProcessId = message.ProcessId;
            this.Data.PersonCount = count;

            for (int i = 1; i <= count; i++)
            {
                PayProcess payProcess = new PayProcess() { ProcessId = message.ProcessId, Count = i };
                Bus.Send(payProcess).Register(PlaceOrderReturnCodeHandler, this);
            }
        }

        private void PlaceOrderReturnCodeHandler(IAsyncResult asyncResult)
        {
            FileWriter.WriteToFile(this.Data.PersonCount.ToString());

            this.Data.PersonCount--;

            if (this.Data.PersonCount == 0)
            {
                PayProcessEnder payProcessEnder = new PayProcessEnder() { ProcessId = this.Data.ProcessId };
                Bus.Send(payProcessEnder);
            }
        }

        public void Handle(PayProcessEnder payProcessEnder)
        {
            this.MarkAsComplete();
        }
    }

    public class FileWriter
    {
        public static void WriteToFile(string message)
        {
            try
            {
                Directory.CreateDirectory(string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Logging"));

                string loggingPath = string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Logging\", DateTime.Now.ToShortDateString().Replace("/", "-"), ".txt");

                StreamWriter writer = new StreamWriter(loggingPath, true);
                writer.WriteLine(string.Concat("Time: ", DateTime.Now.TimeOfDay, "------ Message: ", message));
                writer.Close();
            }
            catch
            {

            }
        }
    }
}

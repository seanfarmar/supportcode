﻿using NServiceBus;

namespace PayrollGenerator.Handler
{
    using System;
    using System.Data.SqlClient;
    using PayrollGenerator.Messages;

    public class ProcessOrderCommandHandler : IHandleMessages<PayProcess>
    {
        public IBus Bus { get; set; }
        public void Handle(PayProcess payProcess)
        {
            using (SqlConnection conn = new SqlConnection("Password=sasql;Persist Security Info=True;User ID=sa;Initial Catalog=Fidelity;Data Source=ghyath_serhal\\v2012"))
            {
                using (SqlCommand cmd = new SqlCommand(string.Format("insert into aaaa values('{0}')", payProcess.Count), conn))
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }

            Console.WriteLine("Executed successfully...");

            Bus.Return(PlaceOrderStatus.Ok);
        }
    }
}

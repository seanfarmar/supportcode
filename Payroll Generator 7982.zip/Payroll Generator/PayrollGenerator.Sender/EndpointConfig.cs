﻿using NServiceBus;

namespace PayrollGenerator.Sender
{
    class EndpointConfig : IConfigureThisEndpoint, AsA_Server {}
}

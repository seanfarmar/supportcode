﻿using System;
using NServiceBus;
using PayrollGenerator.Messages;

namespace PayrollGenerator.Sender
{
    class ProcessOrderSender : IWantToRunWhenBusStartsAndStops
    {
        public IBus Bus { get; set; }

        public void Start()
        {
            Console.WriteLine("Press 'Enter' to send a message. To exit, Ctrl + C");
            var counter = 0;
            while (Console.ReadLine() != null)
            {
                PayProcessStarter payProcessStarter = new PayProcessStarter() { ProcessId = "Test2" };
                Bus.Send(payProcessStarter);

                //PayProcessEnder payProcess = new PayProcessEnder() { ProcessId = "Test14" };
                //Bus.Send(payProcess);
            }
        }

        public void Stop()
        {

        }
    }
}

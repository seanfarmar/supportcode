﻿namespace PayrollGenerator.Messages
{
    public enum PlaceOrderStatus
    {
        Ok,
        Error
    }
}

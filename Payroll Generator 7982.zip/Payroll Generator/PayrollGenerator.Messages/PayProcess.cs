﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NServiceBus.Saga;
using NServiceBus;

namespace PayrollGenerator.Messages
{
    public class PayProcessData : ContainSagaData
    {
        public string Name { get; set; }
        [Unique]
        public string ProcessId { get; set; }
        public string VerificationCode { get; set; }
        public int PersonCount { get; set; }
    }

    public class PayProcess : ICommand
    {
        public string ProcessId { get; set; }
        public int Count { get; set; }
    }

    public class PayProcessStarter : ICommand
    {
        public string ProcessId { get; set; }
    }

    public class PayProcessEnder : ICommand
    {
        public string ProcessId { get; set; }
    }
}

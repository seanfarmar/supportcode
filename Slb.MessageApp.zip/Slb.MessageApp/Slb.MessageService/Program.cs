﻿namespace Slb.MessageService
{
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.Globalization;

    using SimpleInjector;

    using Slb.Bus;
    using Slb.Bus.Nsb;
    using Slb.Bus.Rabbit;
    using Slb.Messages;

    internal class Program
    {
        private static Container container;

        private static IMessageHandler<Send> messageHandler;

        private static IMessageSender<Reply> messageSender;

        static Program()
        {
            Bootstrap();
        }

        [DebuggerStepThrough]
        public static TService GetInstance<TService>() where TService : class
        {
            return container.GetInstance<TService>();
        }

        private static void Main(string[] args)
        {
            messageHandler = GetInstance<IMessageHandler<Send>>();

            messageSender = GetInstance<IMessageSender<Reply>>();

            messageHandler.Handle += MessageHandler_Handle;

            Console.WriteLine("Waiting for messages.");
            Console.ReadKey();
        }

        private static void MessageHandler_Handle(object sender, Send e)
        {
            Console.WriteLine("Message received.");
            var reply = new Reply { Message = string.Format("Reply = {0}", DateTime.Now.ToString(CultureInfo.CurrentCulture)) };
            messageSender.Send(reply);
            Console.WriteLine("Reply sent.");
        }

        private static void Bootstrap()
        {
            var c = new Container();

            if (ConfigurationManager.AppSettings["bus"] == "rabbit")
            {
                c.RegisterSingle<IMessageHandler<Send>, RabbitMessageHandler<Send>>();
                c.RegisterSingle<IMessageSender<Reply>, RabbitMessageSender<Reply>>();
            }
            else
            {
                c.RegisterSingle<IMessageHandler<Send>, NsbMessageHandler<Send>>();
                c.RegisterSingle<IMessageSender<Reply>, NsbMessageSender<Reply>>();
            }

            container = c;
        }
    }
}
﻿namespace Slb.MessageApp
{
    using System;
    using System.Windows.Forms;

    public static class Invoker
    {
        public static void SafeInvoke(this Control control, Delegate method, params object[] args)
        {
            try
            {
                control.Invoke(method, args);
            }
            catch (InvalidOperationException)
            {
                // ignore. this occurs when closing the form and something is running.
            }
        }
    }
}
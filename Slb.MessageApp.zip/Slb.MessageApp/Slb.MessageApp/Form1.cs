﻿namespace Slb.MessageApp
{
    using System;
    using System.Windows.Forms;

    using Slb.Bus;
    using Slb.Messages;

    public partial class Form1 : Form
    {
        private readonly IMessageHandler<Reply> messageHandler;

        private readonly IMessageSender<Send> messageSender;

        public Form1()
        {
            messageSender = Program.GetInstance<IMessageSender<Send>>();
            messageHandler = Program.GetInstance<IMessageHandler<Reply>>();

            messageHandler.Handle += MessageHandler_Handle;

            InitializeComponent();
        }

        private void MessageHandler_Handle(object sender, Reply e)
        {
            UpdateTextBox(e.Message);
        }

        private void SendMessageButtonClick(object sender, System.EventArgs e)
        {
            var send = new Send { Payload = "Howdy" };
            messageSender.Send(send);
        }

        private void UpdateTextBox(string message)
        {
            if (replyTextBox.InvokeRequired)
            {
                Action<string> updateTextBox = UpdateTextBox;
                replyTextBox.SafeInvoke(updateTextBox, message);
                return;
            }

            replyTextBox.Text = message;
        }
    }
}
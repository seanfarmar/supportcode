﻿namespace Slb.MessageApp
{
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.Windows.Forms;

    using SimpleInjector;

    using Slb.Bus;
    using Slb.Bus.Nsb;
    using Slb.Bus.Rabbit;
    using Slb.Messages;

    internal static class Program
    {
        private static Container container;

        [DebuggerStepThrough]
        public static TService GetInstance<TService>() where TService : class
        {
            return container.GetInstance<TService>();
        }

        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Bootstrap();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        private static void Bootstrap()
        {
            var c = new Container();

            if (ConfigurationManager.AppSettings["bus"] == "rabbit")
            {
                c.RegisterSingle<IMessageSender<Send>, RabbitMessageSender<Send>>();
                c.RegisterSingle<IMessageHandler<Reply>, RabbitMessageHandler<Reply>>();
            }
            else
            {
                c.RegisterSingle<IMessageSender<Send>, NsbMessageSender<Send>>();
                c.RegisterSingle<IMessageHandler<Reply>, NsbMessageHandler<Reply>>();
            }
            
            container = c;
        }
    }
}
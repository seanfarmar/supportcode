﻿namespace Slb.Bus.Nsb
{
    using System;

    using NServiceBus;

    public class NsbMessageHandler<T> : Bus.IMessageHandler<T>, IHandleMessages<T>
        where T : class
    {
        public IBus Bus { get; set; }

        void IHandleMessages<T>.Handle(T message)
        {
            if (Handle != null)
            {
                Handle(Bus, message);
            }
        }

        public event EventHandler<T> Handle;
    }
}
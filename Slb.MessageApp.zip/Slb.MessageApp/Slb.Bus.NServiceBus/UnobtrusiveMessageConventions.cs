﻿namespace Slb.Bus.Nsb
{
    using NServiceBus;

    internal class UnobtrusiveMessageConventions : IWantToRunBeforeConfiguration
    {
        public void Init()
        {
            Configure.Instance.DefiningMessagesAs(t => t.Namespace != null && t.Namespace.Equals("Slb.Messages"));
        }
    }
}
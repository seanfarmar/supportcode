﻿namespace Slb.Bus.Nsb
{
    using NServiceBus;

    public class NsbMessageSender<T> : IMessageSender<T>
        where T : class
    {
        public static IBus Bus;

        public NsbMessageSender()
        {
            Configure.ScaleOut(s => s.UseSingleBrokerQueue());

            Configure.Serialization.Xml();
            Configure.Transactions.Enable();

            Bus = Configure.With()
                .DefaultBuilder()
                .PurgeOnStartup(true)
                .UnicastBus()
                .RunHandlersUnderIncomingPrincipal(false)
                .CreateBus()
                .Start(() => Configure.Instance.ForInstallationOn<NServiceBus.Installation.Environments.Windows>().Install());            
        }

        public void Send(T message)
        {
            Bus.Send(message);
        }
    }
}

﻿namespace Slb.Bus.Rabbit
{
    using System.Text;

    using Newtonsoft.Json;

    using RabbitMQ.Client;

    public class RabbitMessageSender<T> : IMessageSender<T>
        where T : class
    {
        public void Send(T message)
        {
            string queue = message.BasicQueueName();

            var factory = new ConnectionFactory { HostName = "localhost" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue, false, false, false, null);

                    string json = JsonConvert.SerializeObject(message);
                    byte[] body = Encoding.UTF8.GetBytes(json);

                    channel.BasicPublish("", queue, null, body);
                }
            }
        }
    }
}
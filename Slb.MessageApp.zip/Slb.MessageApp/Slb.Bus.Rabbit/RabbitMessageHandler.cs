﻿namespace Slb.Bus.Rabbit
{
    using System;
    using System.Text;
    using System.Threading;

    using Newtonsoft.Json;

    using RabbitMQ.Client;
    using RabbitMQ.Client.Events;

    public class RabbitMessageHandler<T> : IMessageHandler<T>
        where T : class
    {
        public RabbitMessageHandler()
        {
            InitializeQueueListener();
        }

        public event EventHandler<T> Handle;

        private void InitializeQueueListener()
        {
            var t = new Thread(QueueListener);
            t.Start();
        }

        private void QueueListener()
        {
            string queue = typeof(T).BasicQueueName();

            var factory = new ConnectionFactory { HostName = "localhost" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue, false, false, false, null);

                    var consumer = new QueueingBasicConsumer(channel);
                    channel.BasicConsume(queue, true, consumer);

                    while (true)
                    {
                        BasicDeliverEventArgs ea = consumer.Queue.Dequeue();

                        byte[] body = ea.Body;
                        string message = Encoding.UTF8.GetString(body);
                        var obj = JsonConvert.DeserializeObject<T>(message);
                        if (Handle != null)
                        {
                            Handle(this, obj);
                        }
                    }
                }
            }
            // ReSharper disable once FunctionNeverReturns
        }
    }
}
﻿namespace Slb.Bus.Rabbit
{
    using System;

    public static class RabbitHelper
    {
        public static string BasicQueueName(this object o)
        {
            return BasicQueueName(o.GetType());
        }

        public static string BasicQueueName(this Type t)
        {
            return string.Format("{0}_basicQueue", t);
        }
    }
}
﻿namespace Slb.Messages
{
    public class Reply
    {
        public string Message { get; set; }
    }
}
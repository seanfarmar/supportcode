﻿namespace Slb.Messages
{
    using System;

    public class Publication
    {
        private DateTime PublicationDateTime { get; set; }
    }
}
﻿namespace Slb.Messages
{
    public class Send
    {
        public string Payload { get; set; }
    }
}
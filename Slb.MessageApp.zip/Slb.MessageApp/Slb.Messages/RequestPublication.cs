﻿namespace Slb.Messages
{
    public class RequestPublication
    {
    }
}
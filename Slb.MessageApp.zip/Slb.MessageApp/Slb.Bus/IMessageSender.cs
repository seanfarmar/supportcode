﻿namespace Slb.Bus
{
    public interface IMessageSender<in T>
        where T : class
    {
        void Send(T message);
    }
}
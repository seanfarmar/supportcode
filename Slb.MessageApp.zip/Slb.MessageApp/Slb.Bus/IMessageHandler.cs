﻿namespace Slb.Bus
{
    using System;

    public interface IMessageHandler<T>
    {
        event EventHandler<T> Handle;
    }
}
﻿namespace Hinda.Internal.ServiceBus.Messages.EPS
{
    public interface IEpsPushoutClientPriceUpdatesMessage : IEpsPushoutClientCatalogMessage
    {
    }
}
﻿namespace Hinda.Internal.ServiceBus.Messages.EPS
{
    public interface IEpsPushoutClientCatalogItemUpdatesMessage : IEpsPushoutClientCatalogMessage
    {
    }
}
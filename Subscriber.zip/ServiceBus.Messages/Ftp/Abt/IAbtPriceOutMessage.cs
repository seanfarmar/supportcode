﻿namespace Hinda.Internal.ServiceBus.Messages.Ftp.Abt
{
    public interface IAbtPriceOutMessage : IFileImportMessage
    {
    }
}
﻿
namespace Hinda.Internal.ServiceBus.Messages.Ftp.Abt
{
    public interface IAbtInvoiceReceivedMessage : IFileImportMessage { }
}

﻿
namespace Hinda.Internal.ServiceBus.Messages.Ftp.IngramEntertainment
{
    public interface IEdiFunctionalAcknowledgementMessage : IFtpFileImportMessage { }
}

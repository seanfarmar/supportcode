﻿namespace Hinda.Internal.ServiceBus.Messages.Ftp.BarnesAndNoble
{
    public interface IBNVideoMessage : IFileImportMessage
    {
    }
}
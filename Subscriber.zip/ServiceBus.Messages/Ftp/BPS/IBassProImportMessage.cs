﻿namespace Hinda.Internal.ServiceBus.Messages.Ftp.BPS
{
    public interface IBassProImportMessage : IFileImportMessage
    {
    }
}
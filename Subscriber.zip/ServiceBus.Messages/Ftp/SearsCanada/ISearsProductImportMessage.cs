﻿namespace Hinda.Internal.ServiceBus.Messages.Ftp.SearsCanada
{
    public interface ISearsProductImportMessage : IFileImportMessage
    {
    }
}
﻿namespace Hinda.Internal.ServiceBus.Messages.Ftp._1800Flowers
{
    public interface I800FlowersImportMessage : IFileImportMessage
    {
    }
}
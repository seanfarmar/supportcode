﻿using NServiceBus;

namespace Hinda.Internal.ServiceBus.Messages.MadisonPerformanceGroup
{
    public interface I488DataImportMessage : IMessage { }
}
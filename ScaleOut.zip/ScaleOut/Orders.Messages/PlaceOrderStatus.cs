﻿namespace Orders.Messages
{
    public enum PlaceOrderStatus
    {
        Ok,
        Error
    }
}

﻿namespace Orders.Events
{
    public class OrderPlaced 
    {
        public string OrderId { get; set; }
    }
}

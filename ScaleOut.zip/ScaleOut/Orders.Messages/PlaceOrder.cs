﻿namespace Orders.Commands
{
    public class PlaceOrder
    {
        public string OrderId { get; set; }
    }
}

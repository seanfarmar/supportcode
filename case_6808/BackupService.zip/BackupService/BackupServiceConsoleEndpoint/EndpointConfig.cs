﻿namespace Slb.BackupServiceConsoleEndpoint
{
    using NServiceBus;

    public class EndpointConfig : IConfigureThisEndpoint, AsA_Server
    {
    }
}

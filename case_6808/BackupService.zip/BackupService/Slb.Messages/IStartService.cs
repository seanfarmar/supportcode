﻿namespace Slb.Messages
{
    public interface IStartService : IMessage
    {
    }
}
﻿namespace Slb.Messages
{
    internal class StartService
    {
    }
}
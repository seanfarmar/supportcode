﻿namespace Slb.Messages
{
    public interface IMessage
    {
    }
}
